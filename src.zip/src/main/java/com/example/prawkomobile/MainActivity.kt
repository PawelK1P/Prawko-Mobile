package com.example.prawkomobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Button

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.glowna)

        val symulacja: Button = findViewById<Button>(R.id.buttonsym)
        symulacja.setOnClickListener(){
            symulacja.setText("Obecnie niedostępne")
        }
    }
}