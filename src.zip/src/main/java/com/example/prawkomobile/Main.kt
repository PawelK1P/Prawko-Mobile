package com.example.prawkomobile
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Button

@Suppress("NAME_SHADOWING")
class Main : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)
        // symulacja
        val symulacja: Button = findViewById(R.id.buttonsim)
        symulacja.setOnClickListener {
            val intent = Intent(this,Simulation::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        // testy
        val testy: Button = findViewById(R.id.buttontest)
        testy.setOnClickListener {
            val intent = Intent(this, Test::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        // egzamin
            val egzamin: Button = findViewById(R.id.buttonexam)
            egzamin.setOnClickListener {
                val intent = Intent(this,Exam::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            }
        // kategorie
            val kategorie: Button = findViewById(R.id.buttoncat)
            kategorie.setOnClickListener {
                val intent = Intent(this,Category::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            }
        // statystyka
            val statystyka: Button = findViewById(R.id.buttonstat)
            statystyka.setOnClickListener {
                val intent = Intent(this,Statistics::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            }
        // Materiały
            val materialy: Button = findViewById(R.id.buttonmaterial)
            materialy.setOnClickListener {
                val intent = Intent(this,Material::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            }
        }
    }