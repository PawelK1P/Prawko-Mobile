package com.example.prawkomobile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Statistics : ComponentActivity() {

    // Zmienna dostępna w całej klasie
    private lateinit var categorySelected: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.statistics)

        // Inicjalizacja TextView z layoutu
        categorySelected = findViewById(R.id.categorySelected)

        // Pobranie wybranej kategorii z SharedPreferences
        val prefs = getSharedPreferences("CategorySelect", Context.MODE_PRIVATE)
        val category = prefs.getString("category", "Nie wybrano")

        // Ustawienie tekstu
        categorySelected.text = "Wybrana kategoria: $category"

        // Obsługa powrotu do menu
        val powrot: Button = findViewById(R.id.back)
        powrot.setOnClickListener {
            val intent = Intent(this, Main::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
