package com.example.prawkomobile

import android.content.Intent
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.doOnLayout

data class LightSpot(val name: String, val area: Rect, val onFrontImage: Boolean)

class Simulation : ComponentActivity() {

    private lateinit var carImage: ImageView
    private lateinit var textWskaz: TextView
    private lateinit var changeImageBtn: Button

    private val frontLights = listOf(
        LightSpot("światła mijania", Rect(50, 100, 90, 140), true),
        LightSpot("światła drogowe", Rect(100, 100, 140, 140), true)
    )

    private val backLights = listOf(
        LightSpot("światła stopu", Rect(60, 120, 100, 160), false),
        LightSpot("światła cofania", Rect(130, 120, 170, 160), false)
    )

    private val allLights = frontLights + backLights

    private lateinit var currentLight: LightSpot
    private var showingFront = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.simulation)

        carImage = findViewById(R.id.carImage)
        textWskaz = findViewById(R.id.textWskaz)
        changeImageBtn = findViewById(R.id.changeImageBtn)
        val backButton: Button = findViewById(R.id.back)

        backButton.setOnClickListener {
            val intent = Intent(this, Main::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        changeImageBtn.setOnClickListener {
            showingFront = !showingFront
            updateImage()
        }

        carImage.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val bitmap = (carImage.drawable as BitmapDrawable).bitmap
                val imageWidth = bitmap.width
                val imageHeight = bitmap.height

                val imageViewWidth = carImage.width
                val imageViewHeight = carImage.height

                // Skalowanie współrzędnych kliknięcia do oryginalnej bitmapy
                val scaleX = imageWidth.toFloat() / imageViewWidth
                val scaleY = imageHeight.toFloat() / imageViewHeight

                val x = (event.x * scaleX).toInt()
                val y = (event.y * scaleY).toInt()

                Log.d("TOUCH", "x: $x, y: $y")

                if (currentLight.area.contains(x, y)) {
                    Toast.makeText(this, "Dobrze! To ${currentLight.name}", Toast.LENGTH_SHORT).show()
                    pickRandomLight()
                } else {
                    Toast.makeText(this, "Źle. Spróbuj jeszcze raz.", Toast.LENGTH_SHORT).show()
                }
            }
            true
        }

        pickRandomLight()
    }

    private fun pickRandomLight() {
        currentLight = allLights.random()
        textWskaz.text = "Wskaż: ${currentLight.name}"
        showingFront = currentLight.onFrontImage
        updateImage()
    }

    private fun updateImage() {
        carImage.setImageResource(
            if (showingFront) R.drawable.car_front else R.drawable.car_back
        )
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
