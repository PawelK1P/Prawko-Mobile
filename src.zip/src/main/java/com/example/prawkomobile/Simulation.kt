package com.example.prawkomobile

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Matrix
import android.os.Bundle
import android.view.MotionEvent
import android.widget.*
import androidx.activity.ComponentActivity

// Procentowy prostokąt (0.0–1.0 względem szerokości i wysokości obrazka)
data class LightArea(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    fun contains(x: Float, y: Float): Boolean =
        x in left..right && y in top..bottom
}

// Dane o świetle: nazwa, obszary, i czy jest z przodu
data class LightSpot(val name: String, val areas: List<LightArea>, val onFrontImage: Boolean)

@Suppress("DEPRECATION")
class Simulation : ComponentActivity() {

    private lateinit var carImage: ImageView
    private lateinit var textPrompt: TextView
    private lateinit var currentLight: LightSpot
    private lateinit var textScore: TextView
    private var showingFront = true

    private val lights = listOf(
        // ŚWIATŁA PRZEDNIE
        LightSpot("Światła mijania", listOf(
            LightArea(0.10f, 0.46f, 0.19f, 0.57f),
            LightArea(0.82f, 0.47f, 0.90f, 0.57f)
        ), true),
        LightSpot("Światła drogowe", listOf(
            LightArea(0.18f, 0.50f, 0.24f, 0.59f),
            LightArea(0.75f, 0.51f, 0.82f, 0.59f)
        ), true),
        LightSpot("Światła przeciwmgłowe przednie", listOf(
            LightArea(0.089f, 0.738f, 0.141f, 0.804f),
            LightArea(0.856f, 0.733f, 0.911f, 0.804f)
        ), true),
        LightSpot("Światła pozycyjne z przodu", listOf(
            LightArea(0.12f, 0.57f, 0.22f, 0.63f),
            LightArea(0.77f, 0.57f, 0.89f, 0.63f)
        ), true),
        LightSpot("Światła kierunkowskazów z przodu", listOf(
            LightArea(0.23f, 0.54f, 0.27f, 0.59f),
            LightArea(0.72f, 0.55f, 0.76f, 0.60f)
        ), true),

        // ŚWIATŁA TYLNE
        LightSpot("Światła stopu", listOf( //skonfigurowane
            LightArea(0.400f, 0.178f, 0.556f, 0.200f),
            LightArea(0.096f, 0.400f, 0.193f, 0.462f),
            LightArea(0.770f, 0.400f, 0.870f, 0.467f)
        ), false),


        LightSpot("Światła pozycyjne tylne", listOf(
            LightArea(0.200f, 0.400f, 0.293f, 0.453f),
            LightArea(0.667f, 0.391f, 0.763f, 0.458f)
        ), false),

        LightSpot("Światła kierunkowskazów tylne", listOf(
            LightArea(0.115f, 0.342f, 0.189f, 0.396f),
            LightArea(0.774f, 0.342f, 0.859f, 0.391f)
        ), false),

        LightSpot("Światła przeciwmgłowe tylne", listOf(
            LightArea(0.130f, 0.751f, 0.281f, 0.804f),
            LightArea(0.674f, 0.760f, 0.830f, 0.813f)
        ), false),

        LightSpot("Światła cofania", listOf(
            LightArea(0.196f, 0.342f, 0.296f, 0.391f),
            LightArea(0.667f, 0.351f, 0.767f, 0.391f)
        ), false),
    )

    @SuppressLint("MissingInflatedId", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.simulation)

        // Inicjalizacja UI elementów
        carImage = findViewById(R.id.carImage)
        textPrompt = findViewById(R.id.textPrompt)
        textScore = findViewById(R.id.textScore)


        // Przycisk zmiany obrazu przód/tył
        findViewById<Button>(R.id.changeImageBtn).setOnClickListener {
            showingFront = !showingFront
            updateImage()
        }

        // Przycisk powrotu do menu głównego
        findViewById<Button>(R.id.back).setOnClickListener {
            startActivity(Intent(this, Main::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            finish()
        }

        // Obsługa dotknięcia obrazka
        carImage.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) checkTouch(event)
            true
        }

        // Pierwsze losowe światło
        pickRandomLight()
    }

    // Ustawienie odpowiedniego obrazka (przód lub tył)
    private fun updateImage() {
        carImage.setImageResource(if (showingFront) R.drawable.car_front else R.drawable.car_back)
    }

    // losowanie świateł
    @SuppressLint("SetTextI18n")
    private fun pickRandomLight() {
        currentLight = lights.random()
        showingFront = currentLight.onFrontImage
        textPrompt.text = "Wskaż: ${currentLight.name}"
        updateImage()
    }

    // Oblicza współrzędne kliknięcia w odniesieniu do oryginalnego obrazka
    private fun getImageCoordinates(event: MotionEvent): Pair<Float, Float> {
        val drawable = carImage.drawable ?: return Pair(-1f, -1f)
        val imageMatrix = carImage.imageMatrix

        val values = FloatArray(9)
        imageMatrix.getValues(values)

        val scaleX = values[Matrix.MSCALE_X]
        val scaleY = values[Matrix.MSCALE_Y]
        val transX = values[Matrix.MTRANS_X]
        val transY = values[Matrix.MTRANS_Y]

        val origW = drawable.intrinsicWidth.toFloat()
        val origH = drawable.intrinsicHeight.toFloat()


        val x = ((event.x - transX) / scaleX).coerceIn(0f, origW)
        val y = ((event.y - transY) / scaleY).coerceIn(0f, origH)


        val normX = x / origW
        val normY = y / origH

        return Pair(normX, normY)
    }

    @SuppressLint("SetTextI18n")
    // Sprawdza, czy użytkownik kliknął w poprawne światło
    private fun checkTouch(event: MotionEvent) {
        val (x, y) = getImageCoordinates(event)

        if (x == -1f || y == -1f) {
            textScore.text = "Błąd: brak obrazka."
            return
        }

        if (currentLight.areas.any { it.contains(x, y) }) {
            textScore.text = "Dobrze! To ${currentLight.name}"
            pickRandomLight()
        } else {
            textScore.text = "Źle. Spróbuj jeszcze raz."
        }
    }

    // Animacja przy wychodzeniu z aktywności
    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
